package com.lar.servicioeterno;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import com.lar.servicioeterno.Tools.PermissionsAplication;

import static com.lar.servicioeterno.Tools.PermissionsAplication.MY_PERMISSIONS_REQUEST_ACTIVITY;
import static com.lar.servicioeterno.Tools.PermissionsAplication.MY_PERMISSIONS_REQUEST_LOCATION;

public class permission_location extends AppCompatActivity {

    boolean bndPermission = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_location);
        CardView cvPermission = findViewById(R.id.cvPermission);
        cvPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermissionLocation();
            }
        });

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }




    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case MY_PERMISSIONS_REQUEST_LOCATION:
                if((grantResults.length >0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)){
                    bndPermission = true;
                }
                break;
        }

        checkBnd();
    }

    private void checkPermissionLocation(){

            if (PermissionsAplication.accesFineLocationPermission(permission_location.this)) {
                bndPermission = true;
            }

            checkBnd();

    }

    private void checkBnd(){
        if(bndPermission){
            Intent intentLocation = new Intent(this,Home.class);
            startActivity(intentLocation);
            finish();
        }
    }
}
