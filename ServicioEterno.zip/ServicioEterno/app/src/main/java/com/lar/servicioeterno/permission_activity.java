package com.lar.servicioeterno;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import com.lar.servicioeterno.Tools.PermissionsAplication;

import static com.lar.servicioeterno.Tools.PermissionsAplication.MY_PERMISSIONS_REQUEST_ACTIVITY;

public class permission_activity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_activity);

        CardView cvPermission = findViewById(R.id.cvPermission);
        cvPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermissionActivity();
            }
        });

        //letras negras
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        //letras blancas
        /*
        View decirView = getWindow().getDecorView();
        decirView.setSystemUiVisibility(decirView.getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

         */
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    boolean bndPermission = false;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case MY_PERMISSIONS_REQUEST_ACTIVITY:
                if((grantResults.length >0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)){
                    bndPermission = true;
                }

            break;
        }

        checkBnd();
    }

    private void checkPermissionActivity(){

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (PermissionsAplication.accessWalkPermission(permission_activity.this)) {
                bndPermission = true;
            }
        }
        else
        {
            bndPermission = true;
        }

        checkBnd();
    }

    private void checkBnd(){
        if(bndPermission){
            Intent intentLocation = new Intent(this,permission_location.class);
            startActivity(intentLocation);
            finish();
        }
    }
}
