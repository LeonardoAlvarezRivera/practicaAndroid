package com.lar.servicioeterno.ui.gallery;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.GenericTransitionOptions;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.lar.servicioeterno.R;

import java.io.File;
import java.io.FileReader;
import java.util.List;

public class photo_adapter extends RecyclerView.Adapter<photo_adapter.photoViewHolder> {
    private Activity activity;
    private List<String> listPhotos;

    public photo_adapter(List<String> list, Activity paramActivity){
        this.activity = paramActivity;
        this.listPhotos = list;

        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public photo_adapter.photoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new photoViewHolder(LayoutInflater.from(parent.getContext()),parent,viewType);
    }

    @Override
    public void onBindViewHolder(@NonNull photo_adapter.photoViewHolder holder, final int position) {
        holder.pathPhoto = this.listPhotos.get(position);

        holder.cvPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(activity,"photo "+position,Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return this.listPhotos.size();
    }

    @Override
    public void onViewAttachedToWindow(@NonNull photoViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        File filePhoto = new File(listPhotos.get(holder.getAdapterPosition()));

        Glide.with(activity)
                .load(filePhoto.getAbsoluteFile())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .transition(GenericTransitionOptions.with(R.anim.nav_default_pop_enter_anim))
                .into(holder.imgPhoto);
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull photoViewHolder holder) {
        super.onViewDetachedFromWindow(holder);

        Glide.with(activity).clear(holder.imgPhoto);
        holder.imgPhoto.clearAnimation();
        holder.imgPhoto.setImageBitmap(null);

    }

    static class photoViewHolder extends RecyclerView.ViewHolder{

        String pathPhoto;
        ImageView imgPhoto;
        CardView cvPhoto;

        public photoViewHolder(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, int paramInt) {
            super(paramLayoutInflater.inflate(R.layout.item_gallery,paramViewGroup,false));

            imgPhoto = this.itemView.findViewById(R.id.imgPhoto);
            cvPhoto = this.itemView.findViewById(R.id.cvPhoto);

        }
    }
}
