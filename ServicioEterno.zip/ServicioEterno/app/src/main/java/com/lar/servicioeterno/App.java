package com.lar.servicioeterno;

import android.app.*;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.Build;

public class App extends Application {
    public static final String CHANNEL_ID = "Tracker";

    public static final String CHANNEL_1_ID = "llamadas";
    public static final String CHANNEL_2_ID = "mensajes";
    public static final String CHANNEL_3_ID = "voz";

    private String CHANNEL_1_NAME = "Notificacion llamadas";
    private String CHANNEL_2_NAME = "Notificacion mensajes";
    private String CHANNEL_3_NAME = "Notificacion voz";
    private String CHANNEL_MAIN_NAME = "Notificacion servicio";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        enableReceptor();
    }


    private void enableReceptor(){
        ComponentName receiver = new ComponentName(getApplicationContext(),BootReceiver.class);

        PackageManager pm = getApplicationContext().getPackageManager();

        pm.setComponentEnabledSetting(receiver,PackageManager.COMPONENT_ENABLED_STATE_ENABLED,PackageManager.DONT_KILL_APP);
    }

    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel1 = new NotificationChannel(CHANNEL_1_ID,CHANNEL_1_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel1.setDescription(CHANNEL_1_NAME);

            NotificationChannel channel2 = new NotificationChannel(CHANNEL_2_ID,CHANNEL_2_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel2.setDescription(CHANNEL_2_NAME);

            NotificationChannel channel3 = new NotificationChannel(CHANNEL_3_ID,CHANNEL_3_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel3.setDescription(CHANNEL_3_NAME);

            NotificationChannel channelMain = new NotificationChannel(CHANNEL_ID,CHANNEL_MAIN_NAME, NotificationManager.IMPORTANCE_HIGH);
            channelMain.setDescription(CHANNEL_MAIN_NAME);

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel1);
            manager.createNotificationChannel(channel2);
            manager.createNotificationChannel(channel3);
            manager.createNotificationChannel(channelMain);
        }
    }
}
