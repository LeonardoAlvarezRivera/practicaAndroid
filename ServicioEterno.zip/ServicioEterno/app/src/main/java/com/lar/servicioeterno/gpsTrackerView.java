package com.lar.servicioeterno;

import android.location.Location;

public interface gpsTrackerView {
    void getCurrentLocation(Location currentLocation);
}
