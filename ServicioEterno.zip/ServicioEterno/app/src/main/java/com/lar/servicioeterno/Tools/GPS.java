package com.lar.servicioeterno.Tools;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.NonNull;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

public class GPS {
    private FusedLocationProviderClient mFusedLocationClient;

    private LocationCallback mLocationCallback;
    private LocationRequest mLocationResquest;

    private LocationSettingsRequest mLocationSettingsRequest;
    private SettingsClient mSettingsClient;

    com.lar.servicioeterno.Tools.gpsTrackerView gpsTrackerView= null;


    Context mContext;
    Activity mActivity;


    public GPS(Context paramContext, Activity activity, gpsTrackerView view){
        this.mContext = paramContext;
        this.mActivity = activity;
        this.gpsTrackerView = view;
        init();
    }

    private  void init(){
        this.mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this.mContext);
        this.mSettingsClient = LocationServices.getSettingsClient(this.mContext);

        this.mLocationCallback = new LocationCallback(){


            public void onLocationResult(LocationResult locationResult){
                super.onLocationResult(locationResult);

                if(locationResult.getLastLocation()!=null){
                    if(gpsTrackerView != null)
                    {
                        gpsTrackerView.getCurrentLocation(locationResult.getLastLocation());
                    }
                }

            }

        };

        this.mLocationResquest = new LocationRequest();
        this.mLocationResquest.setInterval(10000);
        this.mLocationResquest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        this.mLocationResquest.setSmallestDisplacement(0);

        LocationSettingsRequest.Builder locaBuilder = new LocationSettingsRequest.Builder();
        locaBuilder.addLocationRequest(this.mLocationResquest);

        this.mLocationSettingsRequest = locaBuilder.build();

        startLocationRequest();

    }


    private static final int REQUEST_CHECK_SETTINGS = 100;
    private void startLocationRequest(){
        mSettingsClient.checkLocationSettings(mLocationSettingsRequest)
                .addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        Log.i("CONFIGURACION GPS","exitosa");
                        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mActivity != null)
                        {
                            Log.i("PERMISO GPS","Pedir permiso");
                            if(mActivity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                                    mActivity.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                                Log.i("PERMISO","NO LOS TIENES");

                            }else {
                                Log.i("PERMISO","YA LOS TIENES");
                            }

                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        int statusCode = ((ApiException) e).getStatusCode();

                        e.printStackTrace();

                        switch (statusCode){
                            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                try{
                                    ResolvableApiException rae = (ResolvableApiException) e;
                                    rae.startResolutionForResult(mActivity,REQUEST_CHECK_SETTINGS);
                                }catch (IntentSender.SendIntentException loc){
                                    loc.printStackTrace();
                                }

                            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                String errorMessage = "No pueden ser resuelto el error";
                                Log.i("GPS ERROR",errorMessage);
                        }
                    }
                });


    }


    private boolean mRequestingLocationUpdates = false;

    public void startGPSLocation(){

        mFusedLocationClient.requestLocationUpdates(mLocationResquest,mLocationCallback, Looper.myLooper());
        mRequestingLocationUpdates = true;

    }

    public void stopGPSLocation(){
        if(mRequestingLocationUpdates) {
            mRequestingLocationUpdates = false;
            mFusedLocationClient.removeLocationUpdates(mLocationCallback)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            //
                        }
                    });
        }
    }

}
