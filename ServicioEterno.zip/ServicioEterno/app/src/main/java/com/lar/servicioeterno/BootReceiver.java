package com.lar.servicioeterno;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import androidx.core.content.ContextCompat;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals("android.intent.action.BOOT_COMPLETED")){
            Intent serv = new Intent(context,ServicioTest.class);
            ContextCompat.startForegroundService(context,serv);


           // Toast.makeText(context,"Hola ya desperte",Toast.LENGTH_SHORT).show();
        }
    }
}
