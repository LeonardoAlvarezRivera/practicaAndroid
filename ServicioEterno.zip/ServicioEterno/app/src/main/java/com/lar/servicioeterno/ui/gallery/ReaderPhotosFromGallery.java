package com.lar.servicioeterno.ui.gallery;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

public class ReaderPhotosFromGallery {
    public static List<String> getAllPhotos(Context context){
        Uri uri;
        Cursor cursor;

        int column_index_data;

        List<String> photoList = new ArrayList<>();
        String absolutePathOfImage;
        uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.MediaColumns.DATA,MediaStore.Images.Media.BUCKET_DISPLAY_NAME};
        String orderBy = MediaStore.Images.Media.DATE_TAKEN;
        cursor = context.getContentResolver().query(uri,projection,null,null,orderBy + " DESC");
        column_index_data = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        while (cursor.moveToNext()){
            absolutePathOfImage = cursor.getString(column_index_data);
            photoList.add(absolutePathOfImage);
        }
        return  photoList;
    }
}
