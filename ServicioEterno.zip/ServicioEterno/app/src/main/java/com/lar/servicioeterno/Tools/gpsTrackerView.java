package com.lar.servicioeterno.Tools;

import android.location.Location;

public interface gpsTrackerView {
    void getCurrentLocation(Location currentLocation);
}
