package com.lar.servicioeterno;

import android.app.IntentService;
import android.app.Notification;
import android.content.Intent;
import android.location.Location;
import android.os.Build;
import android.os.PowerManager;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import com.lar.servicioeterno.Tools.ActivityRecognition;
import com.lar.servicioeterno.Tools.GPS;
import com.lar.servicioeterno.Tools.gpsTrackerView;

import static com.lar.servicioeterno.App.CHANNEL_ID;

public class ServicioTest extends IntentService implements gpsTrackerView {

    private PowerManager.WakeLock wakeLock;
    private GPS gpsManager;

    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     */
    public ServicioTest() {
        super("ServicioTest");
        setIntentRedelivery(true);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"servicioeterno:WakeLock");
        wakeLock.acquire();

        setMainNotification("Trabajando");

        gpsManager = new GPS(getApplicationContext(),null,this);
        gpsManager.startGPSLocation();

         activityRecognition = new ActivityRecognition(getApplicationContext());
        activityRecognition.init();
    }
    ActivityRecognition activityRecognition;

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        for (;;){

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        gpsManager.stopGPSLocation();
    }

    private void setMainNotification(String message){
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.O){
            Notification notification = new Notification.Builder(this,CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentText(message)
                    .build();

            startForeground(1,notification);
        }else {
            NotificationCompat.Builder localBuilder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentText(message);

            startForeground(1,localBuilder.build());

        }
    }

    @Override
    public void getCurrentLocation(Location currentLocation) {

        sendGPSDataToActivity(currentLocation);

    }

    private void sendGPSDataToActivity(Location location){
        Intent sendGPS = new Intent();
        sendGPS.setAction("GET_SIGNAL_GPS");

        sendGPS.putExtra("LATITUD",String.valueOf(location.getLatitude()));
        sendGPS.putExtra("LONGITUD",String.valueOf(location.getLongitude()));
        sendGPS.putExtra("ALTITUD",String.valueOf(location.getAltitude()));
        sendGPS.putExtra("ACTIVIDAD",String.valueOf(activityRecognition.getCurrentActivity()));

        //activityRecognition.getCurrentActivity();

        sendBroadcast(sendGPS);
    }
}
